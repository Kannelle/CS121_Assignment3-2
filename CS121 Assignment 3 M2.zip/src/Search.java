/*
Haoming Li, 20426226
Kristina Wong, 76513468
Shengjie Xu, 10616769
Yirui Jiang, 64137163
*/

import java.net.*;
import java.io.*;
import java.util.*;

// using Jsoup(in the 'lib' folder) for parsing htmls, so please incude it in the compile path
import org.jsoup.Jsoup;
import org.jsoup.nodes.*;

class Search
{
   private static HashMap<Integer, HashMap<Integer, Double>> indexTfIdf = new HashMap<Integer, HashMap<Integer, Double>>(); // contains termID -> docID, tf-idfs
   private static HashMap<Integer,String> ID_term = new HashMap<Integer,String>(); // contains termID -> term
   private static HashMap<Integer,String> ID_doc = new HashMap<Integer,String>(); // contains docID -> doc
   private static HashMap<String,Integer> term_id = new HashMap<String,Integer>(); // contains term -> termID
   
   private static class Tuple<Double, Integer>{
      public final double totalTfidf;
      public final int docId;
      public Tuple(double totalTfidf,int docId){
         this.totalTfidf = totalTfidf;
         this.docId = docId;
      }
   }
   
   // Comparator used for sorting Tuple by totalTfidf
   public static class TupleComparator implements Comparator<Tuple> {
      public int compare(Tuple a, Tuple b) 
      {
         if(a.totalTfidf > b.totalTfidf) return -1;
         if(a.totalTfidf < b.totalTfidf) return 1;
         return 0;
      }
   }
   
	public static ArrayList<String> readItemInIndex(String text,String delimiter) {
      ArrayList<String> words = new ArrayList<String>();// create an arraylist for seperated word
      String[] parts = text.split(delimiter);// split lines according to the delimiter
      for(String part: parts){
         if(!part.equals("")){
            words.add(part);
         }
      }
		return words;
	}
   

   // read indices from text file into memory/HashMaps
   private static void readMoreIndices(String index) throws Exception {
      File file = new File(index+".txt");
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
         String line = scanner.nextLine();
         String delimiter = "";
         if (index.equals("Index")){
            delimiter += "[:{},= ]";
         }
         else{
            delimiter += "[: ]";
         }
         ArrayList<String> s = readItemInIndex(line,delimiter);
         if(s.size() != 0 && index.equals("Index")){
            HashMap<Integer, Double> temp = new HashMap<Integer, Double>();
            for(int i=1;i<s.size();i+=2){
               temp.put(Integer.parseInt(s.get(i)),Double.parseDouble(s.get(i+1)));
               }
            indexTfIdf.put(Integer.parseInt(s.get(0)),temp);
         }
         else if (s.size() != 0 && index.equals("id_term_index")){
            for(int i=0;i<s.size();i+=2){
               ID_term.put(Integer.parseInt(s.get(i)),s.get(i+1));
               term_id.put(s.get(i+1),Integer.parseInt(s.get(i)));
            }
         }
         else{
            for(int i=0;i<s.size();i+=2){
               ID_doc.put(Integer.parseInt(s.get(i)),s.get(i+1));
            }
         }
      }
      scanner.close();
      
   }
   
   // get a term's (docID->tfidf) pairs
   private static HashMap<Integer, Double> getPageTf(String term){
      try{
         int termId = term_id.get(term);
         return indexTfIdf.get(termId);
      }catch(Exception e){
         try{
            int termId = term_id.get(term.toLowerCase());
            return indexTfIdf.get(termId);
         }catch(Exception m){
            try{
               int termId = term_id.get(term.toUpperCase());
               return indexTfIdf.get(termId);
            }catch(Exception n){
               return null;
            }
         }
      }
   }
   
   
   // get a list of terms' (docID->tfidf) pairs from user's input
   private static ArrayList<HashMap<Integer, Double>> getListOfPageTfs(String inputStr){
      ArrayList<HashMap<Integer, Double>> listOfPageTfs = new ArrayList<HashMap<Integer, Double>>();
      String[] words = inputStr.split(" +",-1);
      List<String> wordlist = new ArrayList<String>(Arrays.asList(words)); 
      wordlist.removeAll(Arrays.asList("", null));
      for(String word : wordlist){
         HashMap<Integer, Double> pageTf = getPageTf(word);
         if (pageTf == null){
            return null;
         }
         else{
            listOfPageTfs.add(pageTf);
         }
      }
      return listOfPageTfs;
   }
   private static void createIndices() throws Exception{
      Modified_Index.mainCreateIndices();
      return;
   }

   public static void main(String args[])throws Exception{
      // construct the indices (txt files)
      System.out.println("\nCreating index files...\n");
      createIndices();
      System.out.println("\nIndex files has been created successfully...\n");
      
      // read from the indices which we have juct created
      System.out.println("Loading id_term_index.txt...");
      readMoreIndices("id_term_index");
      System.out.println("\n--Finished loading id_term_index.txt--\n\nLoading id_doc_index.txt...");
      readMoreIndices("id_doc_index");
      System.out.println("\n--Finished loading id_doc_index.txt--\n\nLoading Index.txt...");
      readMoreIndices("Index");
      System.out.println("\n--Finished loading Index.txt--");
      
      
      while (true){
         Scanner in = new Scanner(System.in);
         System.out.print("\nPlease enter the string you want to search (\"q\" to quit): \n>>> "); // ask for the user input
         String str = in.nextLine();
         if(str.equals("q")){ // if the user type 'q', then the program will be stopped
            System.out.println("--Exit--");
            break;
         }
         System.out.println();
         
         ArrayList<HashMap<Integer, Double>> listOfPageTfs = getListOfPageTfs(str); // contains a list of terms' docID->tfidf from user input
         ArrayList<Tuple<Double,Integer>> pageFindtfidfpair = new  ArrayList<Tuple<Double,Integer>>(); // contains a list of (total tf-idf, docID)
   
         if (listOfPageTfs == null){
            System.out.println("Can not find a page containing '" + str + "'");
         }
         else if (listOfPageTfs.size()==0){
            System.out.println("Please type what you want search...");
         }
         else{
            for(int key : listOfPageTfs.get(0).keySet()){ // for each document which contains the first term(for example:
                                                          // if the user type 'access information','access' will be the first term, 
                                                          // if the user just type 'access','access' will still be the first term)
               int aPage = 0; // used to check if a document contains all the term(s) that user has typyed in
               double tfidfTotal = listOfPageTfs.get(0).get(key); // used to calculate the tf-idf value for a document when the user types multiple terms
                                                                  // (for example: 'access information REST')
               double tfidmin = listOfPageTfs.get(0).get(key);    // same as above
               if (listOfPageTfs.size()!=1){ // if the user has type in more than 1 term
                  // process for checking if the document contains all the term(s) and preparing for recomputing tf-idf
                  for(int i=1; i<listOfPageTfs.size(); i++){ 
                     if(listOfPageTfs.get(i).containsKey(key)){ 
                        aPage+=1;
                        tfidfTotal += listOfPageTfs.get(i).get(key);
                        if(listOfPageTfs.get(i).get(key) < tfidmin){
                           tfidmin = listOfPageTfs.get(i).get(key);
                        }
                     }
                  }
               }
               if(aPage == listOfPageTfs.size()-1){ // if the document contains all the term(s) that user has typyed in
                  double tTfidf = tfidfTotal/(2.0*listOfPageTfs.size())+tfidmin; // a function to get a total tfidf for multiple terms
                  pageFindtfidfpair.add(new Tuple<Double, Integer>(tTfidf,key)); // append (recomputed tf-idf, docID) to an arraylist for sorting
               }
            }
            if(pageFindtfidfpair.size()==0){
               System.out.println(" Can not find a document containing all terms...");
            }
            else{
               Collections.sort(pageFindtfidfpair,new TupleComparator()); // sort the list containing (recomputed tf-idf, docID) pairs by tf-idf
               // print out top 5 resuts(if number of results is less than 5, print all the results)
               int numResultDisplay = pageFindtfidfpair.size();
               if(numResultDisplay>=5){
                  numResultDisplay = 5;
               }
               for(int i=0; i<numResultDisplay;i++){
                  System.out.println(ID_doc.get(pageFindtfidfpair.get(i).docId));
               }
            }
         }
      }
   }
}